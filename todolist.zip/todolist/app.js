angular.module('todoApp', ['ngRoute'])
	.config(['$routeProvider', function($routeProvider) {

		$routeProvider.when('/', {
		// template: '<h5>This is the default route</h5>'
		templateUrl: 'views/home.html'
		})
		.when('/todos', {
		// template: '<h5>This is the default route</h5>'
		templateUrl: 'views/todos.html',
		controller: 'MainCtrl',
		controllerAs: 'mainCtrl'
		})
		.when('/second', {
		// template: '<h5>This is the second route</h5>'
		templateUrl: 'views/second.html'
		})
		.otherwise({redirectTo: '/'});


	}])
	.controller('MainCtrl', [function() {
		var self= this;

		self.appTitle = "TODO APP";

		self.max = 3;

		self.items = [
			{"id": 1, "title": "learn AngularJS", "priority": 1, "done": true},
			{"id": 2, "title": "learn Node", "priority": 1, "done": false},
			{"id": 3, "title": "integrate Mongo", "priority": 2, "done": false}
		];


		/*

		self.items = [];

		$http.get('/todos')
			.then(
				function(response) {
					self.items = response.data;
				},
				function(error) {
					console.error('Error while fetching notes');
				} 
			);
		*/


		self.remaining = function() {
			var todoCount = 0;
			angular.forEach(self.items, function(todoObject) {
				if (todoObject.done) todoCount++;
			});
			return todoCount;
		};


		self.addNew = function() {
			self.items.push({
				"id": self.max+1,
				"title": self.newItem,
				"priority": 1,
				"done": false
			});

			self.max++;
			self.newItem = '';
		};



		// call fetchAll here

		// self.addNew = function() {
		// 	$http.post('/todos', self.newItem)
		// 		.then(getTodos)
		// 		.then(function(response) {
		// 			self.newItem = {};
		// 		});
		// };


	}]);