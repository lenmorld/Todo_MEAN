/*

npm install -g express-generator
express --ejs project_name
cd project_name

npm install
npm install --save mongoose


STRUCTURE
app.js
bin/
node_modules/
package.json
public/
routes/
views/
models/				<-- add


move app.js to public/javascripts/ and rename to angularApp.js
<script src="/javascripts/angularApp.js"></script>



=======
run mongod


GET /posts - return a list of posts and associated metadata
POST /posts - create a new post
GET /posts/:id - return an individual post with associated comments
PUT /posts/:id/upvote - upvote a post, notice we use the post ID in the URL
POST /posts/:id/comments - add a new comment to a post by ID
PUT /posts/:id/comments/:id/upvote - upvote a comment

*/



/*
	server side
*/

// add to orig express routes generated in express generation



var mongoose = require('mongoose');
// require('./models/Todo');				// create /models/Todo schema, or do it directly here 
mongoose.connect('mongodb://localhost/todo');

var TodoSchema = new mongoose.Schema({
	task: String,
	done: Boolean

  // body: String,
  // author: String,
  // upvotes: {type: Number, default: 0},
  // post: { type: mongoose.Schema.Types.ObjectId, ref: 'Post' }
});

var  Todo = mongoose.model('Todo', TodoSchema);
// other models if we have


router.get('/todos', function(req, res, next) {
	Todo.find(function(err, todos) {
		if(err) {return next(err); }

		res.json(todos);
	});
});


router.post('/todos', function(req, res, next) {
	var todo = new Todo(req.body); 		// create mongoose Todo object 

	todo.save(function(err, todo) {
		if(err) {return next(err); }

		res.json(todo);
	});
});








