angular.module('petApp', [])
	.controller('MainCtrl', [function() {
		var self = this;
		self.pets = [
			{name: "Dinesh", color: "brown"},
			{name: "Guilfoyle", color: "white"}
		];
	}]);