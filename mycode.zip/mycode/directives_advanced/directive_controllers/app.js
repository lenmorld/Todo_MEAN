angular.module('petApp', [])
	.controller('MainCtrl', [function() {
		var self = this;
		self.startedTime = new Date().getTime();
		self.pets = [
			{name: "Dinesh", color: "brown"},
			{name: "Guilfoyle", color: "white"}
		];
	}]);