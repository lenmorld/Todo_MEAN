// File: chapter13/directive-slider/noui-slider.js
angular.module('sliderApp')
  .directive('noUiSlider', [function() {
    return {
      restrict: 'E',
      require: 'ngModel',                   // tells AngularJS that ng-model directives must be present on the element our directive is used on
      link: function($scope, $element, $attr, ngModelCtrl) {

        // noUiSlider constructor, this requires jQuery be loaded before Angular in our HTML
        $element.noUiSlider({
          // We might not have the initial value in ngModelCtrl yet
          start: 0,
          range: {
            // $attrs by default gives us string values
            // nouiSlider expects numbers, so convert
            min: Number($attr.rangeMin),
            max: Number($attr.rangeMax)
          }
        });

        // When data changes inside AngularJS
        // Notify the third party directive of the change
        ngModelCtrl.$render = function() {
          $element.val(ngModelCtrl.$viewValue);         // we are overriding $render method on ngModel
        };

        // When data changes outside of AngularJS
        $element.on('set', function(args) {
          // Also tell AngularJS that it needs to update the UI
          $scope.$apply(function() {
            // Set the data within AngularJS
            ngModelCtrl.$setViewValue($element.val());
          });
        });
      }
    };
  }]);
