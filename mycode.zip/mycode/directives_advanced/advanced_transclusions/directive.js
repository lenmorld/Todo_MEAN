// here we define a directive on our petApp module
// the main definition of petApp is in app.js

angular.module('petApp')
	.directive('simplePetRepeat', [function() {
		return {
			// templateUrl: 'pet.html',
			restrict: 'A',
			// transclude: true,

			// capture and replace entire element
			// instead of just its content
			transclude: 'element',		

			// a $transclude is passed in as the fifth argument
			// to the link function
			link: function($scope, $element, $attrs, ctrl, $transclude) {

				var myArray = $scope.$eval($attrs.simplePetRepeat);				// eval var in HTML along with directive(simplePetRepeat) to get a handle
																				// on array we want to repeat on

				var container = angular.element('<div class="container"></div>');

				for (var i = 0; i < myArray.length; i++) {
					// create an element instance with a new child scope
					// using the clone linking function

					var instance = $transclude($scope.$new(),			// transclude function 1st argument (optional) child scope
						function(clonedElement, newScope) {				// 						2nd argument - linking function from the clonedElement
							// expose custom variables for the instance
							newScope.currentIndex = i;											// we add behavior/variable specific to this instance
							newScope.pet = myArray[i];
						}); // end of transclude
					// add it to our container
					container.append(instance);										
				}

				// with transclude: 'element', the element gets replaced
				// with a comment. add our generated content
				// after the comment
				$element.after(container);
			}
		};	
	}])
	// .directive('petWidget', [function() {
	// 	return {
	// 		templateUrl: 'pet.html',
	// 		restrict: 'A',
	// 		transclude: true,				// TRANSCLUSION enabled, this will be added to (not replace) the current HTML inside the directive
	// 		scope: {
	// 			petData: '='
	// 		},
	// 		link: function($scope, $element, $attrs) {
	// 			$scope.getNickname = function(pet) {
	// 				return pet.color + " " + pet.name + 'ie';
	// 			};
	// 		}
	// 	};	
	// }])
	;