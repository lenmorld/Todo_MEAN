angular.module('stockMarketApp')
	.directive('stockWidget', [function() {
		return {
			templateUrl: 'stock.html',
			restrict: 'AE',						// allows <div stock-widget></div>) and <stock-widget></stock-widget>
			
			link: function($scope, $element, $attrs) {
				    self.getChange = function(stock) {
				      return Math.ceil((
				        (stock.price - stock.previous) / stock.previous) * 100);
				    };
			}
		};
}]);



	