angular.module('googleChartApp')
	.directive('pieChart', ['googleChartLoaderPromise',				// depends on the googleChartLoaderPromise service
		function(googleChartLoaderPromise) {
			var convertToPieChartDataTableFormat =						// convert data to Google Map data
				function(firstColumnName, secondColumnName, data) {
					var pieChartArray = [[firstColumnName, secondColumnName]];
					for (var i = 0; i < data.length; i++) {
					pieChartArray.push([data[i].label, data[i].value]);
					}
					return google.visualization.arrayToDataTable(
					pieChartArray);
				};

			return {					// isolated scope of directive
				restrict: 'A',
				scope: {
					chartData: '=',
					chartConfig: '='
				},

			link: function($scope, $element) {							// we use the promise returned from service
				googleChartLoaderPromise.then(function() {
					var chart = new google.visualization.PieChart(
					$element[0]);
					$scope.$watch('chartData', function(newVal, oldVal) {
						var config = $scope.chartConfig;
						if (newVal) {
							chart.draw(
								convertToPieChartDataTableFormat(
									config.firstColumnHeader,
									config.secondColumnHeader,
									newVal
								),
								{title: $scope.chartConfig.title}
							);
						}
					}, true);
				});
			}
			};
}]);