npm install
node server.js