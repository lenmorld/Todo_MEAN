angular.module('stockMarketApp')
	.directive('stockWidget', [function() {
		return {
			templateUrl: 'stock.html',
			restrict: 'AE'						// allows <div stock-widget></div>) and <stock-widget></stock-widget>
		};
}]);



	