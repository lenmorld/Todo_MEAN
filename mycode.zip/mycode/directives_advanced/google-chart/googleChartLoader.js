angular.module('googleChartApp')
	.factory('googleChartLoaderPromise',					
		['$q', '$rootScope', '$window', 
		function($q, $rootScope, $window) {					// ensure pie chart isn't drawn before API is loaded
			// create a Deferred object
			var deferred = $q.defer();

			// load Google charts API async
			$window.google.load('visualization', '1',
			{
				packages: ['corechart'],
				callback: function() {					// callback to be notified when this async task is completed
					/*
						when loaded, trigger the resolve
						but inside an $apply as the event happens
						outside of Angular JS life cycle
					*/
					$rootScope.$apply(function() {	
						deferred.resolve();					// triggers the .then() of API users
					});
				}
			});

			// return the promise object for the direective 
			// to chain onto
			return deferred.promise;
		}]);