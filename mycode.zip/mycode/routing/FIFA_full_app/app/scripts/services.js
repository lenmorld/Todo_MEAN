angular.module('fifaApp')
	.factory('FifaService', ['$http', 				
		function($http) {							// FifaService has two methods, fetch list of teams and details of each team
			return {
				getTeams: function() {
					return $http.get('/api/team');
				},

				getTeamDetails: function() {
					return $http.get('/api/team/' + code);
				}
			}
		}

	])

	.factory('UserService', ['$http', 
		function($http) {										// UserService has 2 methods too, one to check if current user has an active session on the server
			var service = {
				isLoggedIn: false,
				session: function() {
					return $http.get('/api/session')			// returns 400 if user logged in, or user object if yes
					.then(function(response) {					// this callback will be called async when response is available
						service.isLoggedIn = true;
						return response;
					})
				},

				login: function(user) {					
					return $http.post('/api/login', user)			// log in the user
					.then(function(response) {						// POSTs {username: 'myuser', password: 'mypassword'}, if fail returns 400
						service.isLoggedIn = true;
						return response;
					});
				}
			};
			return service;
		}
	])