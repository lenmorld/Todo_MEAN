angular.module('petApp')
	.directive('tabs', [function() {
		return {
			restrict: 'E',
			transclude: true,						// we keep the tab titles in HTML
			scope: true,
			template:   '<div class="tab-headers">'  +								// this will be repeated
						'	<div ng-repeat="tab in tabs"'  +
						'		 ng-click="selectTab($index)"'  +
						'		 ng-class="{selected: isSelectedTab($index)}">'  +
						'		<span ng-bind="tab.title"></span>'  +
						'	</div>'  +
						'</div>'  +
						'<div ng-transclude></div> ',				// NG-TRANSCLUDE - this is where the entire content of tabs directive goes
			controller: function($scope) {							// its own scope that adds functionalities but not collide/override parent's
				var currentIndex = 0;
				$scope.tabs = [];									// $scope members tabs, selectTab, and isSelectedTab are used in the scope of indiv. tab

				this.registerTab = function(title, scope) {			// as a controller function, not accessible from directive's HTML, 
																	// adds a title and scope object to an array used in
																	// displaying the list of tabs at the top (outside the directive)
					if($scope.tabs.length === 0) {
						scope.selected = true;
					} else {
						scope.selected = false;
					}
					$scope.tabs.push({title: title, scope: scope});
				};

				$scope.selectTab = function(index) {
					currentIndex = index;
					for (var i=0; i < $scope.tabs.length; i++) {
						$scope.tabs[i].scope.selected = currentIndex === i;
					}
				};

				$scope.isSelectedTab = function(index) {
					return currentIndex === index;
				};
			}
		};
	}]);