// here we define a directive on our petApp module
// the main definition of petApp is in app.js

angular.module('petApp')
	.directive('petWidget', [function() {
		return {
			templateUrl: 'pet.html',
			restrict: 'A',
			transclude: true,				// TRANSCLUSION enabled, this will be added to (not replace) the current HTML inside the directive
			scope: {
				petData: '='
			},
			link: function($scope, $element, $attrs) {
				$scope.getNickname = function(pet) {
					return pet.color + " " + pet.name + 'ie';
				};
			}
		};	
	}]);