angular.module('fifaApp', ['ngRoute'])
	.config(function($routeProvider) {
		$routeProvider.when('/', {
			templateUrl: 'views/team_details.html',
			controller: 'TeamListCtrl as teamListCtrl'
		})
		.when('/login', {
			templateUrl: 'views/login.html'				// no specified controller since ng-controller defined in HTML
		})
		.when('/team/:code', {												// code is made available to TeamDetailsCtrl as $routeParams.code
			templateUrl: 'views/team_details.html',
			controller: 'TeamDetailsCtrl as teamDetailsCtrl',
			resolve: {														// auth key takes a function, using DI
				auth: ['$q', '$location', 'UserService',					// auth resolve injects UserService into it then makes a call to UserService.session(), which calls /api/session
					function($q, $location, UserService) {								// auth resolve function returns a promise
						return UserService.session().then(					
							function(success){},				// chaining the promise to do nothing in case of success
							function(err) {					    // error handler in the then of the promise to redirect to login screen
								$location.path('/login');				
								$location.replace();					// prevents the path the user accessed from entering browser history
								return $q.reject(err);			// reject promise if case of error to fail the promise
							});
					}]
			}
		});
		$routeProvider.otherwise({
			redirectTo: '/'
		});
	});