angular.module('petApp')
	.directive('tab', [function() {
		return {
			restrict: 'E',
			transclude: true,								// transclusion because it has its own template
			template: '<div ng-show="selected" ng-transclude></div>',		// add the content inside div, with condition to show/hide div based on scope.selected
			require: '^tabs',												// requires that one of the parent HTML elements be the tabs directive, 
																			//and we want tabs directive controller to be available to tab directive
			scope: true,													// scope: true, local vars don't override parent scope
			link: function($scope, $element, $attr, tabCtrl) {				// 4th arg tabCtrl is an instance of the tabs directive controller (dynamically injected)
				tabCtrl.registerTab($attr.title, $scope);							// register tab with parent tabs
			}
		};
	}]);